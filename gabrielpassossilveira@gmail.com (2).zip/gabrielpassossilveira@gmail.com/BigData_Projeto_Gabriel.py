# Databricks notebook source
# MAGIC %md
# MAGIC # Big Data - Projeto Final: Investimentos, Renúncia e Dívida Pública

# COMMAND ----------

# Leitura dos dados (Spark + CSV)
df_invest = spark.read.option("header", True).option("sep", ",").csv("/FileStore/tables/investimentos_ok.csv")
df_divida = spark.read.option("header", True).option("sep", ",").csv("/FileStore/tables/divida_ok.csv")
df_renuncia = spark.read.option("header", True).option("sep", ",").csv("/FileStore/tables/renuncia_ok.csv")
df_cnae = spark.read.option("header", True).option("sep", ",").csv("/FileStore/tables/cnae_ok.csv")

# COMMAND ----------

# Análise e agregação dos dados por ano
from pyspark.sql.functions import year, sum, to_date

# Colunas de data para extração do ano
df_invest = df_invest.withColumn("ano", year("data"))
df_divida = df_divida.withColumn("ano", year("mes do estoque"))
df_renuncia = df_renuncia.withColumnRenamed("f0000_ano", "ano")

# Agregados por ano
inv_ano = df_invest.groupBy("ano").agg(sum("movimento_liquido_reais").alias("investimentos_total"))
div_ano = df_divida.groupBy("ano").agg(sum("valor do estoque").alias("divida_total"))
ren_ano = df_renuncia.groupBy("ano").agg(sum("total").alias("renuncia_total"))

# Join final por ano
df_final_ano = inv_ano.join(div_ano, on="ano", how="outer") \
                      .join(ren_ano, on="ano", how="outer") \
                      .orderBy("ano")

# COMMAND ----------

import plotly.graph_objects as go
from sklearn.preprocessing import MinMaxScaler
import pandas as pd

pdf = df_final_ano.dropna().toPandas()

# Normalizar os dados
scaler = MinMaxScaler()
dados_norm = scaler.fit_transform(pdf[["investimentos_total", "divida_total", "renuncia_total"]])
dados_norm_df = pd.DataFrame(dados_norm, columns=["Investimentos", "Dívida", "Renúncia"])
dados_norm_df["Ano"] = pdf["ano"]

# Criar gráfico interativo
fig = go.Figure()

fig.add_trace(go.Scatter(x=dados_norm_df["Ano"], y=dados_norm_df["Investimentos"],
                         mode='lines+markers', name='Investimentos'))
fig.add_trace(go.Scatter(x=dados_norm_df["Ano"], y=dados_norm_df["Dívida"],
                         mode='lines+markers', name='Dívida'))
fig.add_trace(go.Scatter(x=dados_norm_df["Ano"], y=dados_norm_df["Renúncia"],
                         mode='lines+markers', name='Renúncia'))

fig.update_layout(
    title="📊 Comparativo Normalizado por Ano (Interativo)",
    xaxis_title="Ano",
    yaxis_title="Escala Normalizada (0 a 1)",
    hovermode="x unified",
    template="plotly_white"
)

fig.show()


# COMMAND ----------

# MAGIC %md
# MAGIC 📊 Este gráfico mostra a tendência relativa de três indicadores fundamentais da gestão pública brasileira ao longo dos anos:
# MAGIC
# MAGIC 🟧 Dívida Pública cresceu de forma contínua desde 2017, indicando um aumento progressivo no endividamento do governo.
# MAGIC
# MAGIC 🟩 Renúncia Fiscal manteve-se estável até 2020, mas teve um salto expressivo em 2021, mantendo-se elevada nos anos seguintes — possivelmente reflexo de políticas de incentivo fiscal durante a pandemia.
# MAGIC
# MAGIC 🔵 Investimentos Públicos cresceram até 2018, depois sofreram queda até 2021, mas mostraram forte recuperação em 2022 e 2023, sugerindo um movimento de contenção de gastos seguido de retomada econômica.
# MAGIC
# MAGIC 🧠 Conclusão
# MAGIC O gráfico evidencia que:
# MAGIC
# MAGIC - A dívida pública nunca deixou de crescer.
# MAGIC
# MAGIC - A renúncia fiscal aumentou bruscamente após 2020.
# MAGIC
# MAGIC - Os investimentos públicos foram retomados apenas após o aumento da renúncia e da dívida.
# MAGIC
# MAGIC Em resumo: o governo ampliou gastos indiretos (via renúncia e dívida), e só então voltou a investir diretamente na economia.

# COMMAND ----------

import plotly.express as px

df_regiao = df_invest.filter(~df_invest["regiao"].isin(["NACIONAL"]))

# Total por Região (interativo)
pdf_regiao = df_regiao.groupBy("regiao") \
    .agg(sum("movimento_liquido_reais").alias("total_regiao")) \
    .orderBy("total_regiao", ascending=False).toPandas()

fig = px.bar(pdf_regiao, x="regiao", y="total_regiao",
             title="💰 Total Investido por Região",
             labels={"total_regiao": "Total Investido (R$)", "regiao": "Região"},
             text_auto=True)
fig.update_layout(template="plotly_white")
fig.show()

# Top 10 Funções (interativo, horizontal)
pdf_funcao = df_invest.groupBy("funcao_desc") \
    .agg(sum("movimento_liquido_reais").alias("total_funcao")) \
    .orderBy("total_funcao", ascending=False) \
    .limit(10).toPandas()

fig = px.bar(pdf_funcao, x="total_funcao", y="funcao_desc", orientation="h",
             title="🏛️ Top 10 Funções Públicas por Investimento",
             labels={"total_funcao": "Total Investido (R$)", "funcao_desc": "Função"},
             text_auto=True)
fig.update_layout(template="plotly_white")
fig.show()

df_mun = df_invest.filter(~df_invest["municipio"].isin(["BRASIL", "NACIONAL"]))

# Top 10 Municípios (interativo)
pdf_mun = df_mun.groupBy("municipio") \
    .agg(sum("movimento_liquido_reais").alias("total_municipio")) \
    .orderBy("total_municipio", ascending=False) \
    .limit(10).toPandas()

fig = px.bar(pdf_mun, x="municipio", y="total_municipio",
             title="🏙️ Top 10 Municípios por Investimento",
             labels={"total_municipio": "Total Investido (R$)", "municipio": "Município"},
             text_auto=True)
fig.update_layout(template="plotly_white", xaxis_tickangle=-45)
fig.show()


# COMMAND ----------

# MAGIC %md
# MAGIC 📍 Gráfico 1 – Total Investido por Região
# MAGIC Este gráfico mostra o total de recursos públicos investidos em cada uma das regiões do Brasil durante o período analisado.
# MAGIC É possível observar quais regiões concentraram mais investimentos, refletindo a possível priorização de políticas públicas e repasses federais.
# MAGIC A interação do gráfico permite explorar os valores exatos e comparar o volume entre as regiões.
# MAGIC
# MAGIC 🏛️ Gráfico 2 – Top 10 Funções Públicas por Investimento
# MAGIC Esta visualização destaca as 10 funções de governo que mais receberam investimentos públicos ao longo dos anos.
# MAGIC As funções representam áreas como saúde, educação, segurança e administração.
# MAGIC O gráfico permite identificar quais áreas foram priorizadas em termos de alocação orçamentária.
# MAGIC
# MAGIC 🏙️ Gráfico 3 – Top 10 Municípios por Investimento
# MAGIC Este gráfico apresenta os 10 municípios brasileiros que mais receberam investimentos diretos do governo no período analisado.
# MAGIC A análise evidencia a concentração de recursos em determinadas cidades, o que pode estar associado à relevância estratégica, população, projetos em andamento ou demandas regionais específicas.

# COMMAND ----------

# MAGIC %pip install prophet
# MAGIC
# MAGIC from prophet import Prophet
# MAGIC import pandas as pd
# MAGIC import plotly.graph_objects as go
# MAGIC
# MAGIC df_ml = df_final_ano.dropna().toPandas()
# MAGIC
# MAGIC # Preparar dados de entrada com colunas necessárias
# MAGIC prophet_df = df_ml.copy()
# MAGIC prophet_df["ds"] = pd.to_datetime(prophet_df["ano"], format="%Y")
# MAGIC prophet_df["y"] = prophet_df["investimentos_total"]
# MAGIC prophet_df["divida"] = prophet_df["divida_total"]
# MAGIC prophet_df["renuncia"] = prophet_df["renuncia_total"]
# MAGIC prophet_df = prophet_df[["ds", "y", "divida", "renuncia"]]
# MAGIC
# MAGIC # Modelo Prophet com variáveis externas (regressores)
# MAGIC model = Prophet()
# MAGIC model.add_regressor("divida")
# MAGIC model.add_regressor("renuncia")
# MAGIC model.fit(prophet_df)
# MAGIC
# MAGIC # Gerar datas futuras: 2025 até 2034
# MAGIC future = model.make_future_dataframe(periods=10, freq="Y")
# MAGIC future["divida"] = prophet_df["divida"].mean()
# MAGIC future["renuncia"] = prophet_df["renuncia"].mean()
# MAGIC
# MAGIC # Previsão
# MAGIC forecast = model.predict(future)
# MAGIC
# MAGIC # Separar valores reais e previstos (2025 em diante)
# MAGIC real = forecast[forecast["ds"] <= pd.to_datetime("2024-12-31")]
# MAGIC previsao = forecast[forecast["ds"] > pd.to_datetime("2024-12-31")]
# MAGIC
# MAGIC # Gráfico interativo com Plotly
# MAGIC fig = go.Figure()
# MAGIC
# MAGIC # Linha real
# MAGIC fig.add_trace(go.Scatter(
# MAGIC     x=real["ds"], y=real["yhat"],
# MAGIC     mode="lines+markers",
# MAGIC     name="Investimento Real",
# MAGIC     line=dict(color="green")
# MAGIC ))
# MAGIC
# MAGIC # Linha prevista
# MAGIC fig.add_trace(go.Scatter(
# MAGIC     x=previsao["ds"], y=previsao["yhat"],
# MAGIC     mode="lines+markers",
# MAGIC     name="Previsão (2025–2034)",
# MAGIC     line=dict(color="blue", dash="dash")
# MAGIC ))
# MAGIC
# MAGIC # Layout do gráfico
# MAGIC fig.update_layout(
# MAGIC     title="📈 Previsão de Investimentos com Prophet + Regressores (2025–2034)",
# MAGIC     xaxis_title="Ano",
# MAGIC     yaxis_title="Investimentos (R$)",
# MAGIC     template="plotly_white",
# MAGIC     width=950,
# MAGIC     height=500
# MAGIC )
# MAGIC
# MAGIC fig.show()
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Este gráfico apresenta a previsão dos investimentos públicos no Brasil para os próximos 10 anos (2025 a 2034), utilizando o modelo Prophet com variáveis externas (dívida pública e renúncia fiscal).
# MAGIC
# MAGIC 🔵 Linha azul tracejada: representa a projeção feita com base nos dados históricos de 2015 a 2024, levando em consideração o comportamento da dívida e da renúncia.
# MAGIC
# MAGIC 🟢 Linha verde sólida: mostra os investimentos reais já observados até 2024.
# MAGIC
# MAGIC 🔍 O que o gráfico nos mostra?
# MAGIC - A tendência dos investimentos é de crescimento contínuo na próxima década, superando valores históricos.
# MAGIC
# MAGIC - Isso pode indicar uma retomada mais agressiva dos investimentos públicos, possivelmente associada ao aumento da arrecadação ou estratégias de expansão fiscal.
# MAGIC
# MAGIC - A previsão assume um comportamento médio da dívida e renúncia, ou seja, eventuais mudanças econômicas nesses fatores podem impactar o resultado real.
# MAGIC